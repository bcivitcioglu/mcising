# mcising/__init__.py
from .isinglattice import IsingLattice
from .montecarlo import collect_monte_carlo_data
